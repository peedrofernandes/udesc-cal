class MinHeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }

  private father(index: number): number {
    return Math.ceil(index / 2) - 1
  }

  enqueue(value: number): void {
    this.array[this.array.length] = value

    let father = this.father(thi)
  }

  dequeue(): number {

  }
}