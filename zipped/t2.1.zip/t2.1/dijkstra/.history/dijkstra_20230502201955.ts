export default class MinHeapPriorityQueue {
  private heap: number[]

  constructor() {
    this.heap = []
  }

  private min(n1: number, n2: number): number {
    if (n1 == -1 && n2 == -1) return -1
    if (n1 == -1) return n2
    if (n2 == -1) return n1

    return n1 <= n2 ? n1 : n2
  } 
  private fatherIndex(index: number): number {
    return Math.ceil(index / 2) - 1
  }
  private leftChildIndex(index: number): number {
    return 2 * index + 1
  }
  private rightChildIndex(index: number): number {
    return 2 * index + 2
  }

  printHeap() {
    console.log(this.heap)
  }

  enqueue(value: number): void {
    const len = this.heap.length
    this.heap.push(value)

    let currentIndex = len
    let fatherIndex = this.fatherIndex(currentIndex)
    while (this.heap[fatherIndex] > this.heap[currentIndex]) {
      if (fatherIndex == -1) break

      let aux = this.heap[fatherIndex]
      this.heap[fatherIndex] = this.heap[currentIndex]
      this.heap[currentIndex] = aux

      currentIndex = fatherIndex
      fatherIndex = this.fatherIndex(currentIndex)
    }
  }

  dequeue(): number {
    const dequeuedValue = this.heap[0]

    this.heap[0] = this.heap[this.heap.length - 1]
    let currentIndex = 0
    let currentLeftChildIndex = this.leftChildIndex(currentIndex)
    let currentRightChildIndex = this.rightChildIndex(currentIndex)
    let minChild = this.min(
      this.heap[currentLeftChildIndex], this.heap[currentRightChildIndex]
    )
    while (this.heap[currentIndex] > minChild) {
      if (minChild == this.heap[currentLeftChildIndex]) {
        let aux = this.heap[currentLeftChildIndex]
        this.heap[currentLeftChildIndex] = this.heap[currentIndex]
        this.heap[currentIndex] = aux

        currentIndex = currentLeftChildIndex
      } else {
        let aux = this.heap[currentRightChildIndex]
        this.heap[currentRightChildIndex] = this.heap[currentIndex]
        this.heap[currentIndex] = aux

        currentIndex = currentRightChildIndex
      }
      
      currentLeftChildIndex = this.leftChildIndex(currentIndex)
      currentRightChildIndex = this.rightChildIndex(currentIndex)
      minChild = this.min(
        this.heap[currentLeftChildIndex], this.heap[currentRightChildIndex]
      )
    }
    
    this.heap.pop()
    return dequeuedValue
  }
}

type Vertex = {
  id: string
  pi?: Vertex
  d?: number
}

export class Graph {
  private V: Vertex[]
  private E: [Vertex, Vertex, number][]

  constructor(IDs: string[], E: [string, string, number][]) {
    this.V = IDs.map(id => ({ id }))
    this.E = E.map(([indexV1, indexV2, weight]) => {
      const v1 = this.V.find((v) => v.id === indexV1)

    })
  }
}