class HeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }

  enqueue(value: number): void {
    this.array[this.array.length] =  
  }

  dequeue(): number {

  }
}