class HeapPriorityQueue {
  array: number
}