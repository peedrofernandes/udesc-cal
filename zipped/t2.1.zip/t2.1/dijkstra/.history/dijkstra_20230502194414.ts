export class MinHeapPriorityQueue {
  private heap: number[]

  constructor() {
    this.heap = []
  }

  private fatherIndex(index: number): number {
    return Math.ceil(index / 2) - 1
  }
  private leftChildIndex(index: number): number {
    return 2 * index + 1
  }
  private rightChildIndex(index: number): number {
    return 2 * index + 2
  }

  printHeap() {
    process.stdout.
    for (let i = 0; i < this.heap.length; i++) {
      console.log(this.heap[i])
      if (i != this.heap.length - 1)
        console.log(",")
    }
    console.log("]")
  }

  enqueue(value: number): void {
    const len = this.heap.length
    this.heap.push(value)

    let currentIndex = len
    let fatherIndex = this.fatherIndex(currentIndex)
    while (this.heap[fatherIndex] > this.heap[currentIndex]) {
      if (fatherIndex == -1) break

      let aux = this.heap[fatherIndex]
      this.heap[fatherIndex] = this.heap[currentIndex]
      this.heap[currentIndex] = aux

      currentIndex = fatherIndex
      fatherIndex = this.fatherIndex(currentIndex)
    }
  }

  dequeue(): number {
    const dequeuedValue = this.heap[0]

    this.heap[0] = this.heap[this.heap.length - 1]
    
    return dequeuedValue
  }
}