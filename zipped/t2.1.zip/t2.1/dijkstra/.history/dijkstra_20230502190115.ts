class HeapPriorityQueue {
  
}