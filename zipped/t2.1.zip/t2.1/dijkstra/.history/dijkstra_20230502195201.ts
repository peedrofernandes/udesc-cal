export default class MinHeapPriorityQueue {
  private heap: number[]

  constructor() {
    this.heap = []
  }

  private min(n1: number, n2: number): number {
    return 
  } 
  private fatherIndex(index: number): number {
    return Math.ceil(index / 2) - 1
  }
  private leftChildIndex(index: number): number {
    return 2 * index + 1
  }
  private rightChildIndex(index: number): number {
    return 2 * index + 2
  }

  printHeap() {
    console.log(this.heap)
  }

  enqueue(value: number): void {
    const len = this.heap.length
    this.heap.push(value)

    let currentIndex = len
    let fatherIndex = this.fatherIndex(currentIndex)
    while (this.heap[fatherIndex] > this.heap[currentIndex]) {
      if (fatherIndex == -1) break

      let aux = this.heap[fatherIndex]
      this.heap[fatherIndex] = this.heap[currentIndex]
      this.heap[currentIndex] = aux

      currentIndex = fatherIndex
      fatherIndex = this.fatherIndex(currentIndex)
    }
  }

  dequeue(): number {
    const dequeuedValue = this.heap[0]

    this.heap[0] = this.heap[this.heap.length - 1]
    let currentIndex = 0
    let currentLeftChild = this.leftChildIndex(currentIndex)
    let currentRightChild = this.rightChildIndex(currentIndex)
    while (this.heap[currentIndex])
    
    return dequeuedValue
  }
}