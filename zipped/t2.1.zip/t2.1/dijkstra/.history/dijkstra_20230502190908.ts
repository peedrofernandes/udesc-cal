class MinHeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }

  private father(index: number) {
    return M
  }

  enqueue(value: number): void {
    this.array[this.array.length] = value
  }

  dequeue(): number {

  }
}