class MinHeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }

  private father(index: number): number {
    const fatherIndex = Math.ceil(index / 2) - 1
    return this.array[fatherIndex]
  }
  private leftChild(index: number): number {
    const leftChildIndex = 2 * index + 1
    return this.array[leftChildIndex]
  }
  private rightChild(index: number): number {

  }

  enqueue(value: number): void {
    const len = this.array.length
    this.array[len] = value

    let father = this.father(this.array[len])
    while (father) {
      if (father )
    }
  }

  dequeue(): number {

  }
}