class MinHeapPriorityQueue {
  private heap: number[]

  constructor() {
    this.heap = []
  }

  private fatherIndex(index: number): number {
    return Math.ceil(index / 2) - 1
  }
  private leftChildIndex(index: number): number {
    return 2 * index + 1
  }
  private rightChildIndex(index: number): number {
    return 2 * index + 2
  }

  enqueue(value: number): void {
    const len = this.heap.length
    this.heap.push(value)

    let currentIndex = len
    let fatherIndex = this.fatherIndex(currentIndex)
    while (this.heap[fatherIndex] > this.heap[currentIndex]) {
      let aux = this.heap[fatherIndex]
      this.heap[fatherIndex] = this.heap[currentIndex]
      this.heap[currentIndex] = aux

      fatherIndex = this.fatherIndex()
    }
  }

  dequeue(): number {
    const dequeuedValue = this.heap[0]

    this.heap[0] = this.heap[this.heap.length - 1]


    return dequeuedValue
  }
}