class MinHeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }

  enqueue(value: number): void {
    this.array[this.array.length] = value
    while ()
  }

  dequeue(): number {

  }
}