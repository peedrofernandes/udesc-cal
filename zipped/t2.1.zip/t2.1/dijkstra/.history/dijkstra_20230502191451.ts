class MinHeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }

  private father(index: number): number {
    const fatherIndex = Math.ceil(index / 2) - 1
    return this.array[fatherIndex]
  }
  private leftChild(index: number): number {
    const leftChildIndex = 2 * index + 1
    return this.array[leftChildIndex] || -1
  }
  private rightChild(index: number): number {
    const rightChildIndex = 2 * index + 2
    return this.array[rightChildIndex] || -1

  }

  enqueue(value: number): void {
    const len = this.array.length
    this.array[len] = value

    let currentElem = this.array[len]
    let father = this.father(currentElem)
    while (father > ) {
      if (father )
    }
  }

  dequeue(): number {

  }
}