class MinHeapPriorityQueue {
  private heap: number[]

  constructor() {
    this.heap = []
  }

  private fatherIndex(index: number): number {
    return Math.ceil(index / 2) - 1
  }
  private leftChildIndex(index: number): number {
    return 2 * index + 1
  }
  private rightChildIndex(index: number): number {
    return 2 * index + 2
  }

  enqueue(value: number): void {
    const len = this.heap.length
    this.heap.push(value)

    let currentIndex = len
    while (this.heap[this.fatherIndex(currentIndex)] > this.heap[currentIndex]) {
      let aux = this.heap[this.fatherIndex(currentIndex)]
      
      currentElem = father
    }
  }

  dequeue(): number {

  }
}