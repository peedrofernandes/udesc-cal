class HeapPriorityQueue {
  private array: number[]

  
}