class HeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }
}