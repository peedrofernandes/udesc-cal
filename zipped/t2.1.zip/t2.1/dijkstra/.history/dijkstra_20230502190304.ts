class HeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }

  enqueue(value: number) {
    
  }

  dequeue(value: number) {

  }
}