class HeapPriorityQueue {
  private array: number[]

  constructor() {
    
  }
}