class MinHeapPriorityQueue {
  private array: number[]

  constructor() {
    this.array = []
  }

  private father(index: number): number {
    return Math.ceil(index / 2) - 1
  }
  private leftChild(index: number): number {
    return 2 * index + 1
  }
  private rightChild(index: number): number {
    
  }

  enqueue(value: number): void {
    const len = this.array.length
    this.array[len] = value

    let father = this.father(this.array[len])
    while (father) {
      if (father )
    }
  }

  dequeue(): number {

  }
}