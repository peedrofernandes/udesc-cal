#ifndef INT_BACKPACK_H
#define INT_BACKPACK_H

int intBackpackBottomUp(int n, int W, int *P, int *V);

#endif