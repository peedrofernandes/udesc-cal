#ifndef MERGE_SORT_H
#define MERGE_SORT_H

void mergeSort(void *arr, int size, int elemSize, int (*comp)(void *, void *));

#endif