#!/bin/bash

clear && gcc main.c handlers/* -o main && ./main
