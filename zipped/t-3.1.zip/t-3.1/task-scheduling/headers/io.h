#ifndef IO_H
#define IO_H

void printArray(int* arr, int size);

void printArrayStr(char* str);

void inputString(char* str, int maxSize);

void inputInt(int* n);

#endif