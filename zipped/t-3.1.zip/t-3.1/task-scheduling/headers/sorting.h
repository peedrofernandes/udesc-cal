#include "schedulingTypes.h"

#ifndef SORTING_H
#define SORTING_H

void mergeSortTrains(Train *arr, int size);

#endif